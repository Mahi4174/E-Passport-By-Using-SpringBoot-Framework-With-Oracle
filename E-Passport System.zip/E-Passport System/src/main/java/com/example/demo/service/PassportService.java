package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.PassportRepo;
import com.example.demo.entity.Passport;

@Service	
public class PassportService {
	    @Autowired
	    private PassportRepo passportRepository;
	    public void registerPassport(Passport passport) {
	        passportRepository.save(passport);
	    }
	    public List<Passport> getAllPassports() {
	        return passportRepository.findAll();
	    }
	    public Passport getPassportByPassportNumber(String passportNumber) {
	        return passportRepository.findById(passportNumber).orElse(null);
	    }
	    public void updatePassport(Passport passport) {
	        passportRepository.save(passport);
	    }
	    public void deletePassport(String passportNumber) {
	        passportRepository.deleteById(passportNumber);
	    }
		public void applyForPassport(Passport passport) {
			// TODO Auto-generated method stub
			
		}
	

}
