package com.example.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.dao.CitizenRepo;
import com.example.demo.dao.PassportRepo;
import com.example.demo.entity.Citizen;
import com.example.demo.entity.Passport;
import com.example.demo.service.PassportService;

@Controller
public class passportController {
	@Autowired
	private PassportService passportService;
	
	@Autowired
	PassportRepo repo;
	
	@Autowired
	CitizenRepo crepo;
	
	

	@GetMapping("/register/form")
	public ModelAndView showRegistrationPage() {
		return new ModelAndView("register");
	}

	
//	@SuppressWarnings("null")
	@PostMapping("/register")
	public ModelAndView ProcessApplication(@RequestParam("name") String name, @RequestParam("email") String email,
			@RequestParam("appointmentDate") String appointmentDate,
			@RequestParam("supportingDocs") MultipartFile supportingDocs,@RequestParam("registrationNumber") String registrationNumber) {
		Citizen c = null;
		Optional<Citizen> citizen=crepo.findByRegistrationNumber(registrationNumber);
		ModelAndView modelAndView = new ModelAndView();
		if(citizen.isPresent()) {
			c=citizen.get();
			System.out.println(c);
		 if (!supportingDocs.isEmpty() ) {
           try {
               byte[] bytes = supportingDocs.getBytes();
               Passport passport=new Passport(name, email, appointmentDate,bytes,c);
               passportService.registerPassport(passport);
               String message=passport.getPassportNumber();
               modelAndView.addObject("message" ,message);
           }catch(Exception e){
        	   modelAndView.addObject("error", "Error registering passport: " + e.getMessage());
           }
		 }

	}
		 else {
			 modelAndView.addObject("error", "Please upload supporting documents");
		 }
		 modelAndView.setViewName("register1");
			return modelAndView;
	}
	
	@GetMapping("/changeAppointment")
	public String ChangeAppointmentForm() {
		return "changeAppointment";
	}
	
	
	@PostMapping("/changeAppointmentTime")
	public String ForgotPassword(@RequestParam("passportNumber") String passportNumber,@RequestParam("appointmentDate") String appointmentDate) {
		Optional<Passport> p= repo.findById(passportNumber);
		if(p.isPresent()) {
			Passport b=p.get();
			b.setAppointmentDate(appointmentDate);
			repo.save(b);
			return "Userindex";
		}
		return "changeAppointment";
		
	}
	
//@GetMapping("/view-details")
//	public String viewDetails(@RequestParam("id") Long id, Model model) {
//    Passport <Passport> passport = PassportRepo.findBypassportNumber)(passportNumber));
//    if (passport.isPresent()) {
//        Passport passport = passport.get();
//        model.addAttribute("name", passport.getName());
//        model.addAttribute("regNo", passport.registrationNumber());
//        model.addAttribute("email", passport.getEmail());
//	        model.addAttribute("appointmentDate", passport.getAppointmentDate());
//	        model.addAttribute("passportOfficeAddress", passport.getPassportOfficeAddress());
//        return "view-details"; // assuming that there is a Thymeleaf template named "view-details.html"
//    } else {
//	        model.addAttribute("error", "Passport application not found");
//        return "error"; // assuming that there is a Thymeleaf template named "error.html"
//	    }
//	}
	
	@GetMapping("/ViewApplication")
	public String ViewApplication() {
		return "ViewApplication";
	}
	
	@PostMapping("/ViewApplicationdetails")
	public String ViewApplicationForm(@RequestParam("passportNumber") String passportNumber, Model model) {
		Optional<Passport> p=repo.findById(passportNumber);
		if(p.isPresent()) {
			System.out.println("i invoked");
//			Passport p1;
//			p1.setName(p.get().getName());
			model.addAttribute("details",p);
			System.out.println(p.get());
			return "ViewForm";
		}
		return "ViewApplication";
	}
	
}
	
	

