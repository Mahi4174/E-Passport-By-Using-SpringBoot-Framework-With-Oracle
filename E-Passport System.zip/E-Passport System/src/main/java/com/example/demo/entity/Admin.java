package com.example.demo.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Admin {
	
	@Id
	private String AdminName;
	
	private String AdminPassword;
	
	@OneToMany
	private List<Schedule> appointments=new ArrayList<>();
	
	

	public Admin(String adminName, String adminPassword) {
		super();
		AdminName = adminName;
		AdminPassword = adminPassword;
	}

	public String getAdminName() {
		return AdminName;
	}

	public void setAdminName(String adminName) {
		AdminName = adminName;
	}

	public String getAdminPassword() {
		return AdminPassword;
	}

	public void setAdminPassword(String adminPassword) {
		AdminPassword = adminPassword;
	}

	public List<Schedule> getAppointments() {
		return appointments;
	}

	public void setAppointments(List<Schedule> appointments) {
		this.appointments = appointments;
	}

	
	
	
	
	
	

}
