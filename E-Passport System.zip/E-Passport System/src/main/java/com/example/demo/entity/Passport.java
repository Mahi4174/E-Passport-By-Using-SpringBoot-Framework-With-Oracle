package com.example.demo.entity;

import java.util.concurrent.ThreadLocalRandom;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.OneToOne;
import jakarta.persistence.PrePersist;

@Entity
public class Passport {
	
	@Id
    @Column(unique = true)
	public String passportNumber;
	public String name;
	public String email;
	public String appointmentDate;
	public String Status="Processing";
	
	@OneToOne(cascade = CascadeType.ALL)
	public Citizen citizen;
	
	public String getStatus() {
		return Status;
	}



	public void setStatus(String status) {
		Status = status;
	}

	@Lob
	private byte[] supportingDocs;
	
	
	
	
	 @PrePersist
	    private void generatePassportNumber() {
		 int randomNumber=ThreadLocalRandom.current().nextInt(1000000,9999999);
	    	this.passportNumber="pa"+String.format("%07d", randomNumber);
	    }
	
	

	
	
	

	public Passport(String name, String email, String appointmentDate,byte[] supportingDocs,Citizen citizen) {
		super();
		this.name = name;
		this.email = email;
		this.appointmentDate = appointmentDate;
		this.citizen = citizen;
		this.supportingDocs = supportingDocs;
	}



	public Passport() {
		super();
		// TODO Auto-generated constructor stub
	}



	



	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAppointmentDate() {
		return appointmentDate;
	}

	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}

	public byte[] getSupportingDocs() {
		return supportingDocs;
	}

	public void setSupportingDocs(byte[] supportingDocs) {
		this.supportingDocs = supportingDocs;
	}



	public Citizen getCitizen() {
		return citizen;
	}



	public void setCitizen(Citizen citizen) {
		this.citizen = citizen;
	}
	
	
	

}
