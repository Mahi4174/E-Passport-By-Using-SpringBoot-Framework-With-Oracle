package com.example.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dao.CitizenRepo;
import com.example.demo.entity.Citizen;

@Controller
public class CitizenController {
	
	@Autowired
	CitizenRepo repo;
	
	@GetMapping("/UserRegistration/form")
	public String ShowRegisterForm(Citizen c) {
		return "RegisterCitizen";
	}
	
	/*User registration*/
	
	@PostMapping("/UserRegistration")
	public String Register(Citizen c,BindingResult r,Model m) {
		if(r.hasErrors()) {
			System.out.println(r);
			return "RegisterCitizen";
		}
		repo.save(c);
		String a=c.getRegistrationNumber();
		m.addAttribute("RegistrationNumber",a);
		return "UserRegistered";
	}
	
	@GetMapping("/login/user")
	public String login() {
		return "Userlogin";
	}
	
	/*User Login*/
	
	@PostMapping("/Userlogin")
	public String LoginUser(@RequestParam("registrationNumber") String registrationNumber,@RequestParam("password") String password) {
		Optional<Citizen> c=repo.findByRegistrationNumber(registrationNumber);
		if(c.isPresent() && c.get().getPassword().equals(password)) {
			return "UserIndex";
		}
		return "Userlogin";
		
	}
	
	
	@GetMapping("/forgotPassword")
	public String ForgotPasswordForm() {
		return "forgotPassword";
	}
	
	
	/*forgot password*/
	
	@PostMapping("/forgot")
	public String ForgotPassword(@RequestParam("registrationNumber") String registrationNumber,@RequestParam("password") String password) {
		System.out.println("i invoked");
		Optional<Citizen> c=repo.findByRegistrationNumber(registrationNumber);
		if(c.isPresent()) {
			Citizen b=c.get();
			b.setPassword(password);
			repo.save(b);
			return "UserIndex";
		}
		return "Userlogin";
		
	}
	
	@GetMapping("/user")
	public String UserIndex() {
		return "Userindex";
	}
	
//	@GetMapping("/changeAppointment")
//	public String ChangeAppointmentForm() {
//		return "changeAppointment";
//	}
	
//	public String ForgotPassword(@RequestParam("registrationNumber") String registrationNumber,@RequestParam("password") String password) {
//		Optional<Citizen> c=repo.findByRegistrationNumber(registrationNumber);
//		if(c.isPresent()) {
//			Citizen b=c.get();
//			b.setPassword(password);
//			repo.save(b);
//			return "UserIndex";
//		}
//		return "Userlogin";
//		
//	}

}
